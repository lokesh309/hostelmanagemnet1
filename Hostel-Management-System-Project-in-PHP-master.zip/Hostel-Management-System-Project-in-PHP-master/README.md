:warning:
 This project code is old. Its use [mysql]
# Hostel-Management-System-HMS-
Simple Hostel Management Web Application build with PHP.
Its Just a Student Project.Here have some little bit security bugs.
Please don't use it in real life hostel management. 
If you need help mail me: root@hrshadhin.me

admin login

username- admin

password - password


site :- https://projectworlds.in/php-projects/hostel-management-system-project-in-php/