<footer class="footer text-center text-muted">
&copy; <?php echo date("Y"); ?> - Hostel Management System <a href="https://codeastro.com"></a>
</footer>